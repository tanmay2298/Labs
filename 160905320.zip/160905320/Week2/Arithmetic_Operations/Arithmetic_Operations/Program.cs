﻿using System;

namespace Arithmetic_Operations
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.WriteLine("Enter the numbers:");
            string n1 = Console.ReadLine(); // Readline() method returns string type
            string n2 = Console.ReadLine();
            int.TryParse(n1, out num1);
            int.TryParse(n2, out num2);
            int sum = num1 + num2;
            int diff = num1 - num2;
            int prod = num1 * num2;
            int quo = num1 / num2;
            Console.WriteLine("The result of addition of {0} and {1} is {2}", num1, num2, sum);
            Console.WriteLine("The result of addition of {0} and {1} is {2}", num1, num2, diff);
            Console.WriteLine("The result of addition of {0} and {1} is {2}", num1, num2, prod);
            Console.WriteLine("The result of addition of {0} and {1} is {2}", num1, num2, quo);
            Console.Read(); // Read() accepts only single character
        }
    }
}