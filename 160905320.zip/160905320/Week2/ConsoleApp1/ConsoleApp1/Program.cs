﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int day, month, year, hour, min, sec, ticks;

            Console.WriteLine("Enter the day : ");
            string str = Console.ReadLine();
            int.TryParse(str, out day);

            Console.WriteLine("Enter the month : ");
            str = Console.ReadLine();
            int.TryParse(str, out month);

            Console.WriteLine("Enter the year : ");
            str = Console.ReadLine();
            int.TryParse(str, out year);

            Console.WriteLine("Enter the hour : ");
            str = Console.ReadLine();
            int.TryParse(str, out hour);

            Console.WriteLine("Enter the minutes : ");
            str = Console.ReadLine();
            int.TryParse(str, out min);

            Console.WriteLine("Enter the sec : ");
            str = Console.ReadLine();
            int.TryParse(str, out sec);

            Console.WriteLine("Enter the ticks : ");
            str = Console.ReadLine();
            int.TryParse(str, out ticks);

            ticks = (int)(ticks * 0.0000001);
      

            if(ticks + sec < 60)
            {
                sec = sec + ticks;
            }
            else
            {
                sec = sec + ticks;
                min = min + sec / 60;
                sec = sec % 60;
            }

            if (min >= 60)
            {
                hour = hour + min / 60;
                min = min % 60;
            }
            else
            {
                hour = hour + min / 60;
            }


            if (hour >= 24)
            {
                day = day + hour / 24;
                hour = hour % 24;
            }
            Console.WriteLine("{0}:{1}:{2} {3}:{4}:{5}", day, month, year, hour, min, sec);

            Console.Read();
        }

       
    
    }
}